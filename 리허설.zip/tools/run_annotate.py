"""marks/*.json 을 raw/*.png 에 적용해 annotated/*.png 생성"""
import glob, os, sys, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

for f in sorted(glob.glob(os.path.join(ROOT, 'marks', '*.json'))):
    base = os.path.splitext(os.path.basename(f))[0]
    raw = os.path.join(ROOT, 'raw', base + '.png')
    out = os.path.join(ROOT, 'annotated', base + '.png')
    if not os.path.exists(raw):
        print('skip (no raw):', base)
        continue
    r = subprocess.run([sys.executable, '-X', 'utf8', '-I', os.path.join(HERE, 'annotate.py'), raw, out, f],
                       capture_output=True, text=True)
    print(base, r.stdout.strip() or r.stderr.strip()[:120])
