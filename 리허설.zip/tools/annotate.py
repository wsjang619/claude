"""스크린샷 주석 도구 — 모든 이미지에서 번호·화살표·상자·라벨 크기를 동일하게 유지.

기준: 1600x900 뷰포트 캡처. Notion 에서 가로 ~800px 로 표시되므로 화면상 크기는 이 값의 약 1/2.
  번호 동그라미 지름 56 · 숫자 30 · 라벨 글자 28 · 상자 테두리 5 · 화살표 선 6
색: 빨강=클릭할 곳, 노랑=입력/선택할 값, 초록=확인할 결과
사용:
  python -X utf8 -I annotate.py <raw.png> <out.png> '<marks.json 문자열 또는 파일>'
marks 예:
  [{"t":"box","x":100,"y":50,"w":200,"h":40,"c":"red"},
   {"t":"num","n":1,"x":100,"y":50},                      # 동그라미 중심 좌표
   {"t":"arrow","x1":300,"y1":200,"x2":220,"y2":90},
   {"t":"label","text":"여기를 클릭","x":320,"y":60,"c":"red"}]
"""
import json, os, sys, math
from PIL import Image, ImageDraw, ImageFont

FONT = os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Microsoft', 'Windows', 'Fonts', 'NanumSquareB.ttf')
BASE_W = 1600                      # 기준 가로(px). 다른 폭이면 비율로 환산
COL = {'red': (229, 50, 45), 'yellow': (245, 176, 0), 'green': (22, 163, 74)}
CIRCLE_D, NUM_PT, LABEL_PT, BOX_W, ARROW_W = 56, 30, 28, 5, 6
RING = 3                           # 번호 동그라미 흰 테두리


def font(px):
    return ImageFont.truetype(FONT, px)


def draw_marks(img, marks):
    k = img.width / BASE_W
    S = lambda v: max(1, round(v * k))
    d = ImageDraw.Draw(img, 'RGBA')
    # 1) 상자
    for m in marks:
        if m['t'] == 'box':
            c = COL[m.get('c', 'red')]
            x, y, w, h = m['x'], m['y'], m['w'], m['h']
            if m.get('fill'):
                d.rectangle([x, y, x + w, y + h], fill=c + (45,))
            d.rounded_rectangle([x, y, x + w, y + h], radius=S(6), outline=c, width=S(BOX_W))
    # 2) 화살표
    for m in marks:
        if m['t'] == 'arrow':
            c = COL[m.get('c', 'red')]
            x1, y1, x2, y2 = m['x1'], m['y1'], m['x2'], m['y2']
            d.line([x1, y1, x2, y2], fill=c, width=S(ARROW_W))
            ang = math.atan2(y2 - y1, x2 - x1)
            L, W = S(26), S(14)
            p = [(x2, y2),
                 (x2 - L * math.cos(ang) + W * math.sin(ang), y2 - L * math.sin(ang) - W * math.cos(ang)),
                 (x2 - L * math.cos(ang) - W * math.sin(ang), y2 - L * math.sin(ang) + W * math.cos(ang))]
            d.polygon(p, fill=c)
    # 3) 라벨
    f = font(S(LABEL_PT))
    for m in marks:
        if m['t'] == 'label':
            c = COL[m.get('c', 'red')]
            lines = m['text'].split('\n')
            padx, pady = S(14), S(7)
            wmax = max(d.textlength(t, font=f) for t in lines)
            lh = S(LABEL_PT) + S(6)
            w, h = wmax + 2 * padx, lh * len(lines) + 2 * pady - S(6)
            x, y = m['x'], m['y']
            d.rounded_rectangle([x, y, x + w, y + h], radius=S(10), fill=c + (245,))
            for i, t in enumerate(lines):
                d.text((x + padx, y + pady + i * lh - S(2)), t, font=f, fill=(255, 255, 255))
    # 4) 번호
    nf = font(S(NUM_PT))
    for m in marks:
        if m['t'] == 'num':
            c = COL[m.get('c', 'red')]
            r = S(CIRCLE_D) / 2
            x, y = m['x'], m['y']
            d.ellipse([x - r, y - r, x + r, y + r], fill=(255, 255, 255))
            r2 = r - S(RING)
            d.ellipse([x - r2, y - r2, x + r2, y + r2], fill=c)
            t = str(m['n'])
            tw = d.textlength(t, font=nf)
            d.text((x - tw / 2, y - S(NUM_PT) / 2 - S(2)), t, font=nf, fill=(255, 255, 255))
    return img


def main():
    src, out, marks = sys.argv[1], sys.argv[2], sys.argv[3]
    if os.path.exists(marks):
        marks = open(marks, encoding='utf-8').read()
    img = Image.open(src).convert('RGB')
    draw_marks(img, json.loads(marks))
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    img.save(out, optimize=True)
    print('saved', out, img.size)


if __name__ == '__main__':
    main()
