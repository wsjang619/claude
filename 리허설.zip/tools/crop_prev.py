import sys, os
from PIL import Image
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
n, x1, y1, x2, y2 = sys.argv[1], *map(int, sys.argv[2:6])
im = Image.open(os.path.join(ROOT, 'annotated', n + '.png'))
im.crop((x1, y1, x2, y2)).save(os.path.join(ROOT, 'tools', f'prev_{n}_crop.png'))
print('ok')
